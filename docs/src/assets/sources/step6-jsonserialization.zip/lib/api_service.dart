import 'dart:convert';
import 'package:http/http.dart' as http;
import 'quiz.dart';
import 'shared_prefs_service.dart';
import 'database_service.dart';
import 'mock_service.dart';
import 'package:flutter/foundation.dart';


Future<List<Question>>? fetchQuiz(DatabaseService dbService) async {

  final lastAPICall = await getLastAPICall();
  final now = DateTime.now().millisecondsSinceEpoch;

  if (now - lastAPICall > 300000 || kIsWeb) {
    final response = await http.get(Uri.parse('https://raw.githubusercontent.com/worldline/learning-kotlin-multiplatform/main/quiz.json'));

    if (response.statusCode == 200) {
      storeLastAPICall(now);
      
      // If the server returned a 200 OK response, parse the JSON
      var questions=  Quiz.fromJson(jsonDecode(response.body) as Map<String, dynamic>).questions;
      
      if(!kIsWeb) dbService.saveQuiz(Quiz(questions:questions));
      return questions;
    } else {
      // If the server did not return a 200 OK response, throw an exception.
      return generateMockQuestion();
    }
   
  }else {
    return dbService.getQuiz();
  }
}