import 'package:flutter/material.dart';
import 'welcomescreen.dart';
import 'scorescreen.dart';
import 'questionscreen.dart';
import 'quiz.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz app',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue
      ),
      //home: const WelcomeScreen(),
      //home: const ScoreScreen(score:"10/20"),
      home:  QuestionScreen(questions:generateMockQuestion()),
    );
  }
}


List<Question> generateMockQuestion() {
  return [
    Question(
      id: 1,
      label: "What is Flutter?",
      correctAnswerId: 2,
      answers: [
        Answer(id: 1, label: "A programming language"),
        Answer(id: 2, label: "A UI toolkit"),
        Answer(id: 3, label: "A database"),
        Answer(id: 4, label: "An operating system")
      ],
    ),
    Question(
      id: 2,
      label: "Which company developed Flutter?",
      correctAnswerId: 1,
      answers: [
        Answer(id: 1, label: "Google"),
        Answer(id: 2, label: "Apple"),
        Answer(id: 3, label: "Microsoft"),
        Answer(id: 4, label: "Facebook")
      ],
    ),
    Question(
      id: 3,
      label: "What programming language is used with Flutter?",
      correctAnswerId: 3,
      answers: [
        Answer(id: 1, label: "Java"),
        Answer(id: 2, label: "Kotlin"),
        Answer(id: 3, label: "Dart"),
        Answer(id: 4, label: "Swift")
      ],
    )
    ]; 
    }
    