import 'package:flutter/material.dart';
import 'quiz.dart';

class QuestionScreen extends StatefulWidget {
  final List<Question> questions;
  const QuestionScreen({Key? key, required this.questions}) : super(key: key);


  @override
  State<QuestionScreen> createState() => _QuestionScreenState();
}

class _QuestionScreenState extends State<QuestionScreen> {

  int questionProgress = 0;
  int selectedAnswer = 1;
  int score = 0;

  void _nextOrDone() {
    if (selectedAnswer == widget.questions[questionProgress].correctAnswerId) {
      setState(() {
        score++;
      });
    }
    if (questionProgress < widget.questions.length - 1) {
      setState(() {
        questionProgress++;
        selectedAnswer = 1;
      });
    } else {
      
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    margin: const EdgeInsets.all(60.0),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Text(
                        widget.questions[questionProgress].label,
                        style: const TextStyle(fontSize: 25.0),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: widget.questions[questionProgress].answers
                        .map(
                          (answer) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Radio(
                                  value: answer.id,
                                  groupValue: selectedAnswer,
                                  onChanged: (value) {
                                    setState(() {
                                      selectedAnswer = value as int;
                                    });
                                  },
                                ),
                                const SizedBox(
                                    width:
                                        8), // Adjust the spacing here if needed
                                Text(
                                  answer.label,
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ],
              ),
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () {_nextOrDone();},
              child: questionProgress < widget.questions.length - 1
                  ? const Icon(Icons.arrow_forward)
                  : const Icon(Icons.done),
            ),
            bottomNavigationBar: LinearProgressIndicator(
              value: (questionProgress + 1) / widget.questions.length,
              minHeight: 20.0,
            ),
          );
        }
      }