import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefsService {
  static const String _lastKey = 'last_api_call';

  Future<void> storeLastAPICall(int timestamp) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_lastKey, timestamp);
  }

  Future<int> getLastAPICall() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_lastKey) ?? 0;
  }
}
