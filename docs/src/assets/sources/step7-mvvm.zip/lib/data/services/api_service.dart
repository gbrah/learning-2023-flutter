import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_app/data/model/quiz.dart';

class ApiService {
  final String _baseUrl = 'https://raw.githubusercontent.com/worldline/learning-kotlin-multiplatform/main/quiz.json';

  Future<Quiz?> fetchQuiz() async {
    try {
      final response = await http.get(Uri.parse(_baseUrl));

      if (response.statusCode == 200) {
        return Quiz.fromJson(jsonDecode(response.body) as Map<String, dynamic>);
      }
    } catch (e) {
      // Log error
    }
    return null;
  }
}

