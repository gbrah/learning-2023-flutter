import 'package:path/path.dart';
import 'package:flutter_app/data/model/quiz.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final path = await getDatabasesPath();
    final dbPath = join(path, 'quiz.db');

    return await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE questions (
            id INTEGER PRIMARY KEY,
            label TEXT NOT NULL,
            correct_answer_id INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE answers (
            id INTEGER,
            label TEXT NOT NULL,
            question_id INTEGER NOT NULL,
            PRIMARY KEY (id, question_id),
            FOREIGN KEY (question_id) REFERENCES questions (id) ON DELETE CASCADE
          )
        ''');
      },
    );
  }

  Future<void> saveQuiz(Quiz quiz) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('answers');
      await txn.delete('questions');

      for (var question in quiz.questions) {
        await txn.insert('questions', {
          'id': question.id,
          'label': question.label,
          'correct_answer_id': question.correctAnswerId,
        });

        for (var answer in question.answers) {
          await txn.insert('answers', {
            'id': answer.id,
            'label': answer.label,
            'question_id': question.id,
          });
        }
      }
    });
  }

  Future<Quiz?> getQuiz() async {
    final db = await database;
    final List<Map<String, dynamic>> questionMaps = await db.query('questions');
    if (questionMaps.isEmpty) return null;

    final List<Question> questions = [];

    for (var qMap in questionMaps) {
      final List<Map<String, dynamic>> answerMaps = await db.query(
        'answers',
        where: 'question_id = ?',
        whereArgs: [qMap['id']],
      );

      questions.add(Question(
        id: qMap['id'] as int,
        label: qMap['label'] as String,
        correctAnswerId: qMap['correct_answer_id'] as int,
        answers: answerMaps.map((aMap) => Answer(
          id: aMap['id'] as int,
          label: aMap['label'] as String,
        )).toList(),
      ));
    }

    return Quiz(questions: questions);
  }
}
