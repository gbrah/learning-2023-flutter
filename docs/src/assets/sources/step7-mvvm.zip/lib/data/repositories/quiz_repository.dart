import 'package:flutter/foundation.dart';
import 'package:flutter_app/data/services/database_service.dart';
import 'package:flutter_app/data/services/api_service.dart';
import 'package:flutter_app/data/services/shared_prefs_service.dart';
import 'package:flutter_app/data/model/quiz.dart';
import 'package:flutter_app/data/services/mock_service.dart';

class QuizRepository {
  final ApiService _apiService;
  final DatabaseService? _databaseService;
  final SharedPrefsService _sharedPrefsService;
  final MockService _mockService;

  QuizRepository(
    this._apiService,
    this._databaseService,
    this._sharedPrefsService,
    this._mockService,
  );

  Future<Quiz> getQuiz() async {
    if (kIsWeb) {
      final apiModel = await _apiService.fetchQuiz();
      if (apiModel == null || apiModel.questions.isEmpty) {
        return Quiz(questions: _mockService.generateDummyQuestions());
      }
      return apiModel;
    }

    final lastAPICall = await _sharedPrefsService.getLastAPICall();
    final now = DateTime.now().millisecondsSinceEpoch;

    Quiz? apiModel;

    if (now - lastAPICall > 300000) {
      apiModel = await _apiService.fetchQuiz();
      if (apiModel != null) {
        await _databaseService?.saveQuiz(apiModel);
        await _sharedPrefsService.storeLastAPICall(now);
      }
    }

    apiModel ??= await _databaseService?.getQuiz();

    if (apiModel == null || apiModel.questions.isEmpty) {
      return Quiz(questions: _mockService.generateDummyQuestions());
    }

    return apiModel;
  }

}
