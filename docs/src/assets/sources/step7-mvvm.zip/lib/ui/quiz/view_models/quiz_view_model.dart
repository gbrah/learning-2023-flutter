import 'package:flutter/foundation.dart';
import 'package:flutter_app/data/repositories/quiz_repository.dart';
import 'package:flutter_app/data/model/quiz.dart';
import 'package:flutter_app/utils/command.dart';

class QuizViewModel extends ChangeNotifier {
  final QuizRepository _quizRepository;

  late final Command loadQuizCommand;

  Quiz? _quiz;
  Quiz? get quiz => _quiz;

  int _questionProgress = 0;
  int _selectedAnswerId = 1;
  int _score = 0;
  bool _isFinished = false;

  QuizViewModel(this._quizRepository) {
    loadQuizCommand = Command(_load)..execute();
  }

  Future<void> _load() async {
    final q = await _quizRepository.getQuiz();
    _quiz = q;
    notifyListeners();
  }

  int get questionProgress => _questionProgress;
  int get selectedAnswerId => _selectedAnswerId;
  int get score => _score;
  bool get isFinished => _isFinished;

  void selectAnswer(int answerId) {
    _selectedAnswerId = answerId;
    notifyListeners();
  }

  void nextOrDone(List<Question> questions) {
    if (_selectedAnswerId == questions[_questionProgress].correctAnswerId) {
      _score++;
    }

    if (_questionProgress < questions.length - 1) {
      _questionProgress++;
      _selectedAnswerId = 1; // Reset for next question
      notifyListeners();
    } else {
      _isFinished = true;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    loadQuizCommand.dispose();
    super.dispose();
  }
}
