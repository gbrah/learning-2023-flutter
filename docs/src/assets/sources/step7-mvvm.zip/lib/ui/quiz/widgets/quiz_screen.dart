import 'package:flutter/material.dart';
import 'package:flutter_app/data/model/quiz.dart';
import 'package:flutter_app/ui/quiz/view_models/quiz_view_model.dart';
import 'package:flutter_app/ui/score/widgets/score_screen.dart';

class QuizScreen extends StatefulWidget {
  final QuizViewModel viewModel;

  const QuizScreen({super.key, required this.viewModel});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  @override
  void initState() {
    super.initState();
    widget.viewModel.loadQuizCommand.execute();
    widget.viewModel.addListener(_onViewModelChanged);
  }

  @override
  void dispose() {
    widget.viewModel.removeListener(_onViewModelChanged);
    super.dispose();
  }

  void _onViewModelChanged() {
    if (widget.viewModel.isFinished) {
      final quiz = widget.viewModel.quiz;
      if (quiz != null) {
        Navigator.pushReplacementNamed(
          context,
          "/Score",
          arguments: ScoreScreenArguments(
            '${widget.viewModel.score}/${quiz.questions.length}',
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    return AnimatedBuilder( // in flutter 3 ListenableBuilder
      animation: widget.viewModel.loadQuizCommand,
      builder: (context, _) {
        if (widget.viewModel.loadQuizCommand.running) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (widget.viewModel.loadQuizCommand.error != null) {
          return Scaffold(
            body: Center(child: Text('Error: ${widget.viewModel.loadQuizCommand.error}')),
          );
        }

        final quiz = widget.viewModel.quiz;
        if (quiz != null) {
          return _buildQuizContent(quiz);
        }

        return const Scaffold(
          body: Center(child: Text('Idle')),
        );
      },
    );
  }

  Widget _buildQuizContent(Quiz quiz) {
  return AnimatedBuilder(
    animation: widget.viewModel,
    builder: (context, _) {
      final question = quiz.questions[widget.viewModel.questionProgress];

      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5.0),
                ),
                margin: const EdgeInsets.all(60.0),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: Text(
                    question.label,
                    style: const TextStyle(fontSize: 25.0),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: question.answers
                    .map(
                      (answer) => Padding(
                        padding: const EdgeInsets.symmetric(
                          vertical: 8.0,
                          horizontal: 2.0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Radio<int>(
                              value: answer.id,
                              groupValue: widget.viewModel.selectedAnswerId,
                              onChanged: (int? value) {
                                if (value != null) {
                                  widget.viewModel.selectAnswer(value);
                                }
                              },
                            ),
                            const SizedBox(width: 8),
                            Flexible(
                              child: Text(
                                answer.label,
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                    .toList(),
              ),
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => widget.viewModel.nextOrDone(quiz.questions),
          child: widget.viewModel.questionProgress < quiz.questions.length - 1
              ? const Icon(Icons.arrow_forward)
              : const Icon(Icons.done),
        ),
        bottomNavigationBar: LinearProgressIndicator(
          value: (widget.viewModel.questionProgress + 1) / quiz.questions.length,
          minHeight: 20.0,
        ),
      );
    },
  );
}
}

