import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/data/repositories/quiz_repository.dart';
import 'package:flutter_app/data/services/database_service.dart';
import 'package:flutter_app/data/services/api_service.dart';
import 'package:flutter_app/data/services/shared_prefs_service.dart';
import 'package:flutter_app/data/services/mock_service.dart';
import 'package:flutter_app/ui/quiz/view_models/quiz_view_model.dart';
import 'package:flutter_app/ui/quiz/widgets/quiz_screen.dart';
import 'package:flutter_app/ui/score/widgets/score_screen.dart';
import 'package:flutter_app/ui/welcome/widgets/welcome_screen.dart';

class AppRoutes {
  static const String welcome = '/Welcome';
  static const String quiz = '/Quiz';
  static const String score = '/Score';

  static Map<String, WidgetBuilder> getRoutes(
    QuizRepository quizRepository,
  ) {
    return {
      welcome: (context) => WelcomeScreen(),
      quiz: (context) => QuizScreen(
            viewModel: QuizViewModel(quizRepository),
          ),
      score: (context) => const ScoreScreen(),
    };
  }
}

// Simple dependency injection container
class AppDependencies {
  late final ApiService apiService;
  late final DatabaseService? databaseService;
  late final SharedPrefsService sharedPrefsService;
  late final QuizRepository quizRepository;
  late final MockService mockService;

  AppDependencies() {
    apiService = ApiService();
    databaseService = kIsWeb ? null : DatabaseService();
    sharedPrefsService = SharedPrefsService();

    mockService = MockService();
    quizRepository = QuizRepository(
      apiService,
      databaseService,
      sharedPrefsService,
      mockService,
    );
  }
}
