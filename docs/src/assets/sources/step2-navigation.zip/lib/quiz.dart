class Answer {
  int id;
  String label;
  Answer({
    required this.id,
    required this.label,
  });
}

class Question {
  int id;
  String label;
  int correctAnswerId;
  List<Answer> answers;

  Question({
    required this.id,
    required this.label,
    required this.correctAnswerId,
    required this.answers,
  });

   }

class Quiz {
  List<Question> questions;
  Quiz({required this.questions});
}