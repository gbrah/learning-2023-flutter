import 'quiz.dart';

List<Question> generateMockQuestion() {
  return [
    Question(
      id: 1,
      label: "What is Flutter?",
      correctAnswerId: 2,
      answers: [
        Answer(id: 1, label: "A programming language"),
        Answer(id: 2, label: "A UI toolkit"),
        Answer(id: 3, label: "A database"),
        Answer(id: 4, label: "An operating system")
      ],
    ),
    Question(
      id: 2,
      label: "Which company developed Flutter?",
      correctAnswerId: 1,
      answers: [
        Answer(id: 1, label: "Google"),
        Answer(id: 2, label: "Apple"),
        Answer(id: 3, label: "Microsoft"),
        Answer(id: 4, label: "Facebook")
      ],
    ),
    Question(
      id: 3,
      label: "What programming language is used with Flutter?",
      correctAnswerId: 3,
      answers: [
        Answer(id: 1, label: "Java"),
        Answer(id: 2, label: "Kotlin"),
        Answer(id: 3, label: "Dart"),
        Answer(id: 4, label: "Swift")
      ],
    )
    ]; 
    }
    