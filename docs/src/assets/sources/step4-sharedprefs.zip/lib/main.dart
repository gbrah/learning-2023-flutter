import 'package:flutter/material.dart';
import 'welcomescreen.dart';
import 'scorescreen.dart';
import 'questionscreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz app',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue
      ),
      initialRoute: '/Welcome',
      routes: {
      '/Welcome': (context) => WelcomeScreen(),
      '/Quiz': (context) => QuestionScreen(),
      '/Score': (context) => ScoreScreen(score:(ModalRoute.of(context)!.settings.arguments as ScoreArguments).score )
      },

       
    );
  }
}

