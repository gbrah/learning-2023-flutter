import 'package:shared_preferences/shared_preferences.dart';

  Future<void> storeLastAPICall(int timestamp) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt("last_api_call", timestamp);
  }

  Future<int> getLastAPICall() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt("last_api_call") ?? 0;
  }
